# 🚀 Micro Frontend (MFE) Demo Project

A simple demonstration of Module Federation architecture with a host application and a remote MFE.

## 📁 Project Structure

```
mfe-demo/
├── host-app/          # Host application that loads the remote MFE
└── remote-app/        # Remote MFE application
```

## 🎯 What This Demonstrates

- **Module Federation**: Dynamic loading of remote applications at runtime
- **Independent Deployment**: Host and remote can be deployed separately
- **Data Sharing**: Passing context and data from host to remote
- **Clean Architecture**: Following PowerSchool MFE patterns

## 🛠️ Setup Instructions

### 1. Install Dependencies

```bash
# Install host app dependencies
cd host-app
npm install

# Install remote app dependencies
cd ../remote-app
npm install
```

### 2. Run Both Applications

**Terminal 1 - Remote App (must start first):**
```bash
cd remote-app
npm run dev
```
This starts on `http://localhost:5002`

**Terminal 2 - Host App:**
```bash
cd host-app
npm run dev
```
This starts on `http://localhost:5001`

### 3. Open in Browser

Navigate to `http://localhost:5001` to see the host app loading the remote MFE!

## 📦 How It Works

### Host Application (`host-app`)

1. **App.tsx**: Main component that renders the MfeComponent
2. **MfeComponent.tsx**: Wrapper that handles Module Federation loading
   - Initializes federation runtime
   - Registers the remote
   - Loads the remote module
   - Passes initialization data
   - Handles cleanup on unmount

### Remote Application (`remote-app`)

1. **mfe-bootstrap.tsx**: Entry point exposed via Module Federation
   - Exports `psMfeInit` function
   - Receives element and data from host
   - Creates React root
   - Renders the app with context
   - Returns cleanup function

2. **vite.config.ts**: Configures Module Federation
   - Sets remote name: `ps_mfe_demo_app`
   - Exposes `./RemoteApp` module
   - Generates `remoteEntry.js`

## 🔑 Key Components

### MfeComponent Interface
```typescript
interface MfeComponentProps {
  url: string;              // Where the MFE is hosted
  module: string;           // Module to load (e.g., "./RemoteApp")
  remote: string;           // Remote name (e.g., "ps_mfe_demo_app")
  moduleType: string;       // Type of module
  initializationData?: {};  // Data to pass to MFE
}
```

### MFE Bootstrap Interface
```typescript
export default {
  psMfeInit(config: PsMfeInitParams) {
    // Initialize MFE
    return Promise.resolve({
      unloadMfe: () => {
        // Cleanup function
      }
    });
  }
};
```

## 🎨 What You'll See

- **Host App**: Purple gradient background with user info panel
- **Remote MFE**: Dynamically loaded section showing:
  - User data received from host
  - API URL
  - Feature flags
  - MFE capabilities

## 🔄 Architecture Flow

```
┌─────────────────────────────────────────┐
│  Host App (localhost:5001)              │
│  ┌───────────────────────────────────┐  │
│  │ App.tsx                            │  │
│  │  └─ MfeComponent                  │  │
│  │      • Init Federation            │  │
│  │      • Register Remote            │  │
│  │      • Load & Mount MFE           │  │
│  └───────────────┬───────────────────┘  │
└──────────────────┼──────────────────────┘
                   │
                   │ HTTP Request
                   ▼
┌─────────────────────────────────────────┐
│  Remote App (localhost:5002)            │
│  ┌───────────────────────────────────┐  │
│  │ remoteEntry.js                     │  │
│  │  └─ mfe-bootstrap.tsx             │  │
│  │      • Receives element & data    │  │
│  │      • Creates React root         │  │
│  │      • Renders App                │  │
│  └───────────────────────────────────┘  │
└─────────────────────────────────────────┘
```

## 🚦 Common Issues

1. **CORS Error**: Make sure remote app is running first on port 5002
2. **Module not found**: Check that remote name matches in both configs
3. **Build issues**: Ensure all dependencies are installed

## 📚 Learn More

- [Module Federation Docs](https://module-federation.io/)
- [Vite Module Federation Plugin](https://github.com/module-federation/vite)

## ✨ Next Steps

Try modifying:
- Pass different data from host to remote
- Add more exposed modules in remote
- Create additional MFE components
- Add routing within the MFE

---

**Happy coding! 🎉**

