import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { federation } from '@module-federation/vite';

export default defineConfig({
  plugins: [
    react(),
    federation({
      name: 'ps_mfe_demo_app',
      filename: 'remoteEntry.js',
      exposes: {
        './RemoteApp': './src/mfe-bootstrap.tsx',
      },
    }),
  ],
  server: {
    port: 5002,
    cors: true,
  },
  preview: {
    port: 5002,
  },
  build: {
    target: 'esnext',
  },
});

