import { createRoot } from 'react-dom/client';
import { StrictMode } from 'react';
import App from './App';
import { AppContext, AppContextType } from './context/AppContext';

type PsMfeInitParams = { element: HTMLElement } & AppContextType;

export default {
  psMfeInit(config: PsMfeInitParams) {
    console.log('Initializing Remote MFE', config);
    
    const { apiUrl, currentUser, featureFlags } = config;

    const context: AppContextType = {
      apiUrl,
      currentUser,
      featureFlags,
    };

    const root = createRoot(config.element);
    
    root.render(
      <StrictMode>
        <AppContext.Provider value={context}>
          <App />
        </AppContext.Provider>
      </StrictMode>
    );

    return Promise.resolve({
      unloadMfe: () => {
        console.log('Unloading Remote MFE');
        root.unmount();
      },
    });
  },
};

