import { createContext } from 'react';

export interface AppContextType {
  apiUrl?: string;
  currentUser?: {
    username: string;
    email: string;
    role: string;
  };
  featureFlags?: Record<string, any>;
}

export const AppContext = createContext<AppContextType | null>(null);

