import { useContext } from 'react';
import './App.css';
import { AppContext } from './context/AppContext';

function App() {
  const context = useContext(AppContext);

  return (
    <div className="remote-app">
      <div className="content">
        <h2>🚀 Remote MFE Application</h2>
        <p className="subtitle">This component is loaded dynamically via Module Federation</p>

        <div className="info-section">
          <h3>📊 Data Received from Host:</h3>
          
          <div className="info-card">
            <h4>Current User</h4>
            <pre>{JSON.stringify(context?.currentUser, null, 2)}</pre>
          </div>

          <div className="info-card">
            <h4>API URL</h4>
            <pre>{context?.apiUrl || 'Not provided'}</pre>
          </div>

          <div className="info-card">
            <h4>Feature Flags</h4>
            <pre>{JSON.stringify(context?.featureFlags, null, 2)}</pre>
          </div>
        </div>

        <div className="demo-section">
          <h3>✨ MFE Capabilities</h3>
          <ul>
            <li>✅ Receives data from host application</li>
            <li>✅ Runs independently with its own React context</li>
            <li>✅ Can be deployed separately from host</li>
            <li>✅ Loaded at runtime, not build time</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;

