import { useState } from 'react';
import './App.css';
import { MfeComponent } from './components/MfeComponent';

function App() {
  const [userInfo] = useState({
    username: 'demo_user',
    email: 'demo@example.com',
    role: 'admin',
  });

  return (
    <div className="app">
      <header className="app-header">
        <h1>🏠 Host Application</h1>
        <p>Demonstrating Module Federation with MFE</p>
      </header>

      <div className="control-panel">
        <h2>Host Controls</h2>
        <div className="user-info">
          <h3>User Information</h3>
          <p><strong>Username:</strong> {userInfo.username}</p>
          <p><strong>Email:</strong> {userInfo.email}</p>
          <p><strong>Role:</strong> {userInfo.role}</p>
        </div>
      </div>

      <div className="mfe-container">
        <div className="mfe-header">
          <h2>📦 Remote MFE (Loaded Dynamically)</h2>
        </div>
        <MfeComponent
          url="http://localhost:5002/remoteEntry.js"
          module="./RemoteApp"
          remote="ps_mfe_demo_app"
          moduleType="module"
          initializationData={{
            apiUrl: 'https://api.example.com',
            currentUser: userInfo,
            featureFlags: {
              darkMode: true,
              betaFeatures: false,
            },
          }}
        />
      </div>
    </div>
  );
}

export default App;
