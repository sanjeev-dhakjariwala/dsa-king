import React, { useEffect, useRef } from 'react';
import { init, loadRemote, registerRemotes } from '@module-federation/enhanced/runtime';
import type { RemoteEntryType } from '@module-federation/sdk';

interface MfeComponentProps {
  /** The URL where the MFE is hosted */
  url: string;
  /** This corresponds to a key in the MFE's build configuration exposes object. */
  module: string;
  /** This corresponds to the name field in the MFE's build configuration */
  remote: string;
  /** What type of module is being exported */
  moduleType: RemoteEntryType;
  /** Any data provided here will be passed along to the psMfeInit function */
  initializationData?: Record<string, any>;
}

/**
 * PowerSchool MFE Module Interface
 */
interface PowerSchoolMfeModule {
  default: {
    psMfeInit: (props: {
      element: HTMLElement;
      [key: string]: any;
    }) => void | Promise<{ unloadMfe: () => void }>;
  };
}

// Initialize module federation runtime once
const federationHost = init({
  name: 'host_app',
  remotes: [],
});

type MountStatus = 'unmounted' | 'pending' | 'mounted';

export const MfeComponent = (props: MfeComponentProps) => {
  const mfeHostRef = useRef<HTMLDivElement>(null);
  const mountStatusRef = useRef<MountStatus>('unmounted');

  useEffect(() => {
    if (mountStatusRef.current !== 'unmounted') {
      return;
    }

    mountStatusRef.current = 'pending';

    let unloadMfe: (() => void) | undefined;

    // Register the remote if not already registered
    if (!federationHost.moduleCache.has(props.remote)) {
      registerRemotes([
        {
          name: props.remote,
          entry: props.url,
          type: props.moduleType,
        },
      ]);
    }

    // Combine remote name and module name
    const id = props.remote + props.module.replace(/^\./, '');

    loadRemote<PowerSchoolMfeModule>(id)
      .then((importedModule) => {
        if (typeof importedModule?.default?.psMfeInit !== 'function') {
          throw new Error('Module does not have a psMfeInit function');
        }

        const initReturn = importedModule.default.psMfeInit({
          element: mfeHostRef.current!,
          ...props.initializationData,
        });

        // If init function returns a promise, wait for it to resolve
        if (initReturn && 'then' in initReturn) {
          initReturn.then(({ unloadMfe: unload }) => {
            unloadMfe = unload;
          });
        }

        mountStatusRef.current = 'mounted';
      })
      .catch((err) => {
        mountStatusRef.current = 'unmounted';
        console.error('Failed to load MFE:', err);
      });

    return () => {
      unloadMfe?.();
    };
  }, []);

  return <div ref={mfeHostRef} />;
};

