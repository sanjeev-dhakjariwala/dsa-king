import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { init } from '@module-federation/enhanced/runtime';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5001,
    cors: true,
  },
  preview: {
    port: 5001,
  },
});

